from django.contrib import admin

admin.site.site_header = "TourLink Administration"
admin.site.site_title = "TourLink Admin"
admin.site.index_title = "Marketplace management"
