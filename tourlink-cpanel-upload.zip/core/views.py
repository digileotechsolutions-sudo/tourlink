import os

from django.http import JsonResponse
from django.shortcuts import redirect


def home(request):
    return redirect(os.getenv("DJANGO_FRONTEND_URL", "http://localhost:3000"))


def health(request):
    return JsonResponse({"status": "ok", "service": "tourlink-django"})
