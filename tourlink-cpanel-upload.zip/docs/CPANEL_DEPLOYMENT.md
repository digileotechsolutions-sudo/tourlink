# cPanel deployment

TourLink currently has two application layers:

- The production user interface and existing API routes run on Next.js.
- The Django service is a migration backend and currently exposes `/api/health/`.

Deploy them as separate cPanel applications during the migration. Do not point both applications at the same domain path. The simplest layout is:

- `www.example.com` -> the Next.js application
- `api.example.com` -> the Django application

Keep the source in a private directory such as `/home/CPANEL_USER/tourlink`. The public `public_html` directory should only contain any cPanel-managed proxy or redirect files.

## Next.js application

Use cPanel's **Application Manager** or **Setup Node.js App**.

1. Upload the repository, excluding `.git`, `.next`, `node_modules`, `.venv`, `django.sqlite3`, and local databases.
2. Set the application root to the repository directory.
3. Select Node.js 20 or newer.
4. Set the application mode to `Production`.
5. Set the startup command to `npm start` if cPanel provides a command field. If cPanel asks for an application startup file instead, use the hosting provider's Node.js application configuration for the `npm start` script.
6. Configure the environment variables in `.env.example` in cPanel's environment-variable panel. At minimum set `DATABASE_URL`, `SESSION_SECRET`, `NEXT_PUBLIC_APP_URL`, `OTP_DEV_MODE=false`, and the credentials for every integration enabled in production. Do not upload `.env` or commit secrets.
7. Run these commands in the cPanel terminal from the application root:

```bash
npm ci
npx prisma generate
npx prisma db push
npm run build
```

This repository currently has no committed `prisma/migrations` directory, so `prisma db push` is required for the first database bootstrap. After creating and committing a migration history, use `npx prisma migrate deploy` for subsequent releases instead. Do not run `prisma db push` on an established production database unless you have reviewed the schema changes and accepted the risks.

8. Restart the Node.js application from cPanel.
9. Point the domain or subdomain to the Node.js application using cPanel's assigned application URL or proxy configuration.
10. Verify the site, login flow, and application health checks before switching DNS.

The application listens on the port supplied by cPanel. The existing `next start` script respects the `PORT` environment variable.

## Django application

Create a second cPanel **Setup Python App** application.

1. Choose Python 3.11 or newer.
2. Set the application root to the repository directory, or to a separate directory containing the Django backend. If both apps share the repository, use the same uploaded source but keep separate cPanel application entries.
3. Set the application URL to an API subdomain such as `api.example.com`.
4. Set the startup file to `passenger_wsgi.py`.
5. Set the entry point to `application`.
6. Open the virtual environment path shown by cPanel and install dependencies:

```bash
source /home/CPANEL_USER/virtualenv/TOUR_LINK/3.11/bin/activate
pip install -r requirements-django.txt
python manage.py migrate --noinput
python manage.py collectstatic --noinput
```

Replace `CPANEL_USER`, the virtual environment directory, and the Python version with the values shown by cPanel.

Set these Python application environment variables in cPanel:

```text
DJANGO_DEBUG=false
DJANGO_SECRET_KEY=<long-random-secret>
DJANGO_ALLOWED_HOSTS=api.example.com
DJANGO_DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DATABASE
DJANGO_FRONTEND_URL=https://www.example.com
DJANGO_SECURE_SSL_REDIRECT=true
DJANGO_SECURE_HSTS_SECONDS=31536000
```

Restart the Python application and verify:

```text
https://api.example.com/api/health/
```

The Django admin console is available separately at `https://api.example.com/django-admin/`. The Next.js admin login remains at `https://your-domain.example/admin/login`.
```

## Database

Create a PostgreSQL database and database user in cPanel. Add the complete connection string to `DATABASE_URL` for Prisma and to `DJANGO_DATABASE_URL` for Django. They may use the same PostgreSQL database, but they manage separate schema histories. Run the initial Prisma bootstrap described above, then run Django migrations. Create a Django superuser only if the Django admin is needed:

```bash
python manage.py createsuperuser
```

## HTTPS and integrations

Enable AutoSSL for both domains before production traffic. Configure the M-Pesa callback as:

```text
https://your-domain.example/api/mpesa/callback
```

Ensure the callback reaches the Next.js application until the payment API is migrated to Django. Configure external email, SMS, storage, and worker credentials through cPanel environment variables rather than committing them. Set `NEXT_PUBLIC_APP_URL` to the public HTTPS URL, not the cPanel application URL.

## Important limitation

The Django backend is not yet a full replacement for the Next.js application. It currently provides the Django runtime and health endpoint. Authentication, trips, vehicles, bookings, payments, and dashboards remain in the Next.js/Prisma application until those features are migrated and tested.
